import json
import os

from drift_demo import TextJoiner

words = json.loads(os.environ["DOCDRIFT_INPUT"])
result = TextJoiner().join(words)
print(json.dumps(result, sort_keys=True))
