import json
import os

from drift_demo import TokenStats

words = json.loads(os.environ["DOCDRIFT_INPUT"])
result = TokenStats().measure(words)
print(json.dumps(result["total"], sort_keys=True))
