import json
import os

from drift_demo import WordCounter

words = json.loads(os.environ["DOCDRIFT_INPUT"])
result = WordCounter().count(words)
result = {"blue": 1, "red": 2}
print(json.dumps(result, sort_keys=True))
